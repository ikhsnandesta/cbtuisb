package id.web.uisb.cbt;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.*;

public class MainActivity extends Activity {
  static final String URL = "https://cbt.uisb.web.id/";
  WebView web;
  boolean terkunci = false;

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    web = new WebView(this);
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    s.setUserAgentString(s.getUserAgentString() + " CBTUISBApp");
    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
        return !r.getUrl().getHost().endsWith("uisb.web.id"); // hanya situs CBT
      }
      @Override public void doUpdateVisitedHistory(WebView v, String url, boolean reload) {
        aturKunci(url.contains("/peserta/ujian"));
      }
    });
    web.setWebChromeClient(new WebChromeClient());
    setContentView(web);
    if (b != null) web.restoreState(b); else web.loadUrl(URL);
    layarPenuh();
  }

  void aturKunci(boolean kunci) {
    if (kunci == terkunci) return;
    terkunci = kunci;
    try { if (kunci) startLockTask(); else stopLockTask(); } catch (Exception ignored) {}
  }

  void layarPenuh() {
    web.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
      | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
  }

  @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) layarPenuh(); }
  @Override protected void onSaveInstanceState(Bundle o) { super.onSaveInstanceState(o); web.saveState(o); }
  @Override public void onBackPressed() { if (terkunci) return; if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
